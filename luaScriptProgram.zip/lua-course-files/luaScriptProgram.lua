// Andrew Powell luaScriptProgram
// 11/25/2024

Print("Welcome to Andrew Powell's Hello World Program")
print("Hello, World!")
print(5 * 3)
print("Thank You!")